package com.example.statki;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button[][] buttons = new Button[10][10];
    private int[][] board = new int[10][10];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Adjust padding for edge-to-edge layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initButtons();
        placeShips();
    }

    private void initButtons() {
        // Initialize buttons grid
        for (int i = 0; i < 10; i++) {
            String rowId = "row" + i;
            int rowResId = getResources().getIdentifier(rowId, "id", getPackageName());
            LinearLayout rowLayout = findViewById(rowResId);

            if (rowLayout == null) {
                Log.e("MainActivity", "Row layout not found: " + rowId);
                continue;
            }

            for (int j = 0; j < 10; j++) {
                String buttonId = "button" + i + j;
                int resId = getResources().getIdentifier(buttonId, "id", getPackageName());
                buttons[i][j] = rowLayout.findViewById(resId);

                if (buttons[i][j] == null) {
                    Log.e("MainActivity", "Button not found: " + buttonId);
                    continue;
                }

                // Set button click listener
                int finalI = i;
                int finalJ = j;
                buttons[i][j].setOnClickListener(v -> handleClick(finalI, finalJ));
            }
        }
    }

    private void handleClick(int i, int j) {
        // Handle button click and update board
        if (board[i][j] == 1) {
            buttons[i][j].setText("X");
            board[i][j] = 2;
        } else if (board[i][j] == 0) {
            buttons[i][j].setText("O");
            board[i][j] = 3;
        }
        buttons[i][j].setEnabled(false);
    }

    private void placeShips() {
        // Manually placing ships on the board
        board[2][3] = 1;
        board[2][4] = 1;
        board[5][5] = 1;
        board[7][1] = 1;
    }
}

